/**
 * POST /api/analyze — 食事写真を解析して PFC を返す（Cloudflare Pages Functions）
 *
 * ■ 既定：Cloudflare Workers AI（APIキー不要・無料枠あり）
 *   Pages プロジェクト > 設定 > バインディング > 「Workers AI」を追加し、変数名を AI にする
 *
 * ■ 環境変数（すべて任意）
 *   AI_PROVIDER        : workers-ai（既定） / claude
 *   WORKERS_AI_MODEL   : 画像を読むモデル（既定 @cf/meta/llama-3.2-11b-vision-instruct）
 *   WORKERS_AI_TEXT_MODEL : 料理名の日本語化に使う軽いモデル（既定 @cf/meta/llama-3.1-8b-instruct）
 *   ANTHROPIC_API_KEY  : AI_PROVIDER=claude のときだけ必要
 *   CLAUDE_MODEL       : 既定 claude-sonnet-5-5
 *   DAILY_LIMIT        : 1人（IP）1日あたりの解析回数（既定 10）
 *   RATE_KV            : KV バインディング。設定すると回数制限が有効
 */

const MAX_BASE64 = 2_000_000;
const JA = /[぀-ヿ一-鿿]/;

const PROMPT_JA = `あなたは管理栄養士です。添付の食事写真に写っている料理と量を推定し、栄養価を見積もってください。
日本の一般的な食品成分表を基準に、見た目の量から推定します。
次のJSONだけを返してください（説明文やコードブロックは不要）:
{"name":"料理名（複数なら「・」で区切る、30文字以内）","kcal":数値,"p":たんぱく質g,"f":脂質g,"c":炭水化物g,"items":[{"name":"品名","amount":"推定量"}],"comment":"ダイエット中の人へのひとこと（40文字以内・やさしい口調）"}
食べ物が写っていない場合は {"error":"食事が見つかりませんでした"} を返してください。`;

// Llama 3.2 Vision は画像＋英語の指示が最も安定するため、英語で指示して数値を取り、名前は後で日本語化する
const PROMPT_EN = `You are a registered dietitian. Identify every dish and drink in this meal photo, estimate the portion sizes, and estimate the total nutrition of the whole meal (assume typical Japanese portions and recipes).
Reply with ONLY one JSON object, no markdown, no explanation:
{"name":"short dish name(s), joined with ' and '","kcal":number,"p":protein_g,"f":fat_g,"c":carbohydrate_g,"items":[{"name":"item","amount":"estimated amount e.g. 150 g, 1 bowl"}],"comment":"one short friendly tip for someone on a diet"}
If there is no food in the image, reply {"error":"no food"}.`;

const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' },
  });

function pickJson(text) {
  const m = String(text || '').match(/\{[\s\S]*\}/);
  if (!m) return null;
  try { return JSON.parse(m[0]); } catch {
    // 末尾カンマなど軽い崩れを直して再挑戦
    try { return JSON.parse(m[0].replace(/,\s*([}\]])/g, '$1')); } catch { return null; }
  }
}
const textOf = r => (typeof r === 'string' ? r : r?.response ?? r?.result?.response ?? r?.choices?.[0]?.message?.content ?? '');

/* ---------- Cloudflare Workers AI ---------- */
async function runWorkersAI(env, dataUrl) {
  if (!env.AI) throw { status: 503, error: 'AI解析はまだ設定されていません（Workers AI のバインディング未設定）' };
  const model = env.WORKERS_AI_MODEL || '@cf/meta/llama-3.2-11b-vision-instruct';
  const input = {
    messages: [
      { role: 'system', content: 'You output strict JSON only.' },
      { role: 'user', content: PROMPT_EN },
    ],
    image: dataUrl,
    max_tokens: 500,
    temperature: 0.2,
  };
  let r;
  try {
    r = await env.AI.run(model, input);
  } catch (e) {
    // Llama 3.2 Vision は初回だけ Meta のライセンス同意が必要 → 自動で同意して再実行
    if (/agree|licen[sc]e/i.test(String(e?.message || e)) && model.includes('llama-3.2')) {
      await env.AI.run(model, { prompt: 'agree' }).catch(() => {});
      r = await env.AI.run(model, input);
    } else throw e;
  }
  const out = pickJson(textOf(r));
  if (!out) throw { status: 502, error: '解析結果を読み取れませんでした。もう一度撮ってみてね' };
  if (out.error) throw { status: 422, error: '食事が見つかりませんでした' };

  // 料理名・品名・ひとことを日本語に（軽いテキストモデルで1回だけ）
  const needJa = [out.name, out.comment, ...(out.items || []).map(i => i.name)].some(s => s && !JA.test(s));
  if (needJa) {
    try {
      const src = { name: out.name, comment: out.comment, items: (out.items || []).slice(0, 8).map(i => ({ name: i.name, amount: i.amount })) };
      const t = await env.AI.run(env.WORKERS_AI_TEXT_MODEL || '@cf/meta/llama-3.1-8b-instruct', {
        messages: [
          { role: 'system', content: 'Translate the JSON values into natural Japanese for a Japanese diet app. Dish names should be common Japanese names (e.g. 唐揚げ定食, 鶏むねサラダ). Convert amounts to Japanese (e.g. 150g, 1杯). The comment must be friendly casual Japanese under 40 characters. Keep the same JSON keys. Output JSON only.' },
          { role: 'user', content: JSON.stringify(src) },
        ],
        max_tokens: 400,
        temperature: 0.2,
      });
      const ja = pickJson(textOf(t));
      if (ja) {
        if (ja.name) out.name = ja.name;
        if (ja.comment) out.comment = ja.comment;
        if (Array.isArray(ja.items) && ja.items.length) out.items = ja.items;
      }
    } catch (e) { console.warn('translate failed', e); }
  }
  if (out.name && !JA.test(out.name)) out.name = String(out.name).replace(/ and /g, '・');
  return out;
}

/* ---------- Claude（任意） ---------- */
async function runClaude(env, b64) {
  if (!env.ANTHROPIC_API_KEY) throw { status: 503, error: 'AI解析はまだ設定されていません（APIキー未設定）' };
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'x-api-key': env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({
      model: env.CLAUDE_MODEL || 'claude-sonnet-5-5',
      max_tokens: 600,
      messages: [{ role: 'user', content: [
        { type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: b64 } },
        { type: 'text', text: PROMPT_JA },
      ] }],
    }),
  });
  if (!res.ok) {
    console.error('Anthropic API error', res.status, (await res.text().catch(() => '')).slice(0, 300));
    throw { status: res.status === 429 || res.status === 529 ? 503 : 502, error: res.status === 429 || res.status === 529 ? '混み合っています。少し時間をおいて試してください' : '解析に失敗しました。手入力してください' };
  }
  const data = await res.json();
  const out = pickJson((data.content || []).filter(c => c.type === 'text').map(c => c.text).join(''));
  if (!out) throw { status: 502, error: '解析結果を読み取れませんでした' };
  if (out.error) throw { status: 422, error: String(out.error) };
  return out;
}

/* ---------- handler ---------- */
export async function onRequestPost({ request, env }) {
  const origin = request.headers.get('origin');
  if (origin && new URL(origin).host !== new URL(request.url).host) return json({ error: '許可されていない呼び出し元です' }, 403);

  let body;
  try { body = await request.json(); } catch { return json({ error: 'リクエストが不正です' }, 400); }
  const raw = typeof body?.image === 'string' ? body.image : '';
  const b64 = raw.replace(/^data:image\/\w+;base64,/, '');
  if (!b64) return json({ error: '画像がありません' }, 400);
  if (b64.length > MAX_BASE64) return json({ error: '画像が大きすぎます' }, 413);

  if (env.RATE_KV) {
    const ip = request.headers.get('cf-connecting-ip') || 'unknown';
    const day = new Date(Date.now() + 9 * 3600e3).toISOString().slice(0, 10);
    const key = `rl:${day}:${ip}`;
    const limit = Number(env.DAILY_LIMIT || 10);
    const used = Number((await env.RATE_KV.get(key)) || 0);
    if (used >= limit) return json({ error: `今日の写真解析（${limit}回）を使い切りました。明日また使ってね`, code: 'rate_limited' }, 429);
    await env.RATE_KV.put(key, String(used + 1), { expirationTtl: 60 * 60 * 26 });
  }

  const provider = (env.AI_PROVIDER || 'workers-ai').toLowerCase();
  let out;
  try {
    out = provider === 'claude' ? await runClaude(env, b64) : await runWorkersAI(env, 'data:image/jpeg;base64,' + b64);
  } catch (e) {
    if (e && e.error) return json({ error: e.error }, e.status || 500);
    const msg = String(e?.message || e);
    console.error('analyze failed', msg);
    if (/capacity|rate|limit|429|neuron/i.test(msg)) return json({ error: '今日のAI解析の上限に達したか、混み合っています。時間をおいて試すか手入力してね', code: 'rate_limited' }, 503);
    return json({ error: '解析に失敗しました。手入力してください' }, 502);
  }

  const num = v => Math.max(0, Math.round(Number(v) || 0));
  let kcal = num(out.kcal);
  const p = num(out.p), f = num(out.f), c = num(out.c);
  if (!kcal && (p || f || c)) kcal = p * 4 + f * 9 + c * 4;
  return json({
    name: String(out.name || '').slice(0, 40),
    kcal, p, f, c,
    items: Array.isArray(out.items) ? out.items.slice(0, 8).map(i => ({ name: String(i?.name || '').slice(0, 20), amount: String(i?.amount || '').slice(0, 20) })) : [],
    comment: String(out.comment || '').slice(0, 60),
    provider,
  });
}

/* GET /api/analyze — 設定チェック用（キーの中身は返さない） */
export async function onRequestGet({ env }) {
  const provider = (env.AI_PROVIDER || 'workers-ai').toLowerCase();
  return json({
    ok: provider === 'claude' ? !!env.ANTHROPIC_API_KEY : !!env.AI,
    provider,
    model: provider === 'claude' ? (env.CLAUDE_MODEL || 'claude-sonnet-5-5') : (env.WORKERS_AI_MODEL || '@cf/meta/llama-3.2-11b-vision-instruct'),
    rateLimit: env.RATE_KV ? Number(env.DAILY_LIMIT || 10) : 'off',
  });
}
