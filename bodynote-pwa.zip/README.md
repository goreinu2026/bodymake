# BODY NOTE（ダイエット＆トレーニング記録 WEBアプリ）

Cloudflare Pages ＋ GitHub で公開する、ホーム画面に追加できるWEBアプリ（PWA）です。

## フォルダ構成
```
public/                 ← 公開されるファイル一式
  index.html            アプリ本体
  manifest.webmanifest  ホーム画面追加用の設定
  sw.js                 オフライン対応（Service Worker）
  _headers              Cloudflare用のキャッシュ設定
  img/                  ナビのイラスト20種
  icons/                アプリアイコン・OGP画像
  vendor/               Chart.js
functions/api/analyze.js  食事写真のAI解析（Claude API）。APIキーはここだけで使い、ページには出ない
```

## 公開手順

### 1. GitHub にアップロード
1. GitHub で新しいリポジトリを作成（例：`bodynote`、Private でもOK）
2. 「uploading an existing file」から、このフォルダの中身（`public` `functions` `README.md` `.gitignore`）をまとめてドラッグ＆ドロップ → Commit

### 2. Cloudflare Pages につなぐ
1. Cloudflare ダッシュボード → **Workers & Pages** → **作成** → **Pages** → **Git に接続**
2. 上で作ったリポジトリを選択
3. ビルド設定
   - フレームワーク プリセット：**なし**
   - ビルドコマンド：**（空欄）**
   - ビルド出力ディレクトリ：**public**
4. 保存してデプロイ → `https://bodynote-xxx.pages.dev` で公開されます

### 3. 写真解析（AI）を有効にする — Cloudflare Workers AI（APIキー不要）
1. Pages プロジェクト → **設定** → **バインディング** → **追加** → **Workers AI**
   - 変数名：`AI`（大文字）
   - 「本番」環境に追加（プレビューでも試すなら両方）
2. **デプロイ** タブから最新のデプロイを「再試行」して反映
3. ブラウザで `https://（あなたのURL）/api/analyze` を開き、`"ok":true` と出れば設定完了
4. スマホで食事写真を1枚撮って試す
   - 初回だけ、Meta の Llama ライセンスへの同意を自動で行います（使うモデル：Llama 3.2 11B Vision）

> 無料枠：Workers AI は無料プランでも1日ごとの無料枠（Neurons）があります。超えた日は「今日の上限に達しました」と表示され、手入力に切り替わります。使用量は Cloudflare ダッシュボードの **AI** → **Workers AI** で確認できます。

### 4.（おすすめ）使いすぎ防止の回数制限
1. Cloudflare → **ストレージとデータベース** → **KV** → 名前空間を作成（例：`bodynote-rate`）
2. Pages プロジェクト → **設定** → **バインディング** → **KV名前空間** を追加
   - 変数名：`RATE_KV`／名前空間：作ったもの
3. 必要なら **変数とシークレット** に `DAILY_LIMIT`（1人1日の解析回数、既定 10）を追加
4. 再デプロイ

### （将来）解析AIを切り替える
**変数とシークレット** で次を設定して再デプロイするだけで切り替わります。
| やりたいこと | 設定 |
|---|---|
| Claude に切り替え（精度重視・有料） | `AI_PROVIDER` = `claude`、`ANTHROPIC_API_KEY` = キー（シークレット） |
| Workers AI の別モデルを試す | `WORKERS_AI_MODEL` = 例 `@cf/meta/llama-4-scout-17b-16e-instruct` |

### 5.（任意）独自ドメイン
Pages プロジェクト → **カスタムドメイン** から設定できます。

## 更新のしかた
GitHub のファイルを書き換えて Commit すると、Cloudflare が自動で再デプロイします。
画像やアプリを更新したときは `public/sw.js` の `VERSION`（例：`bn-v1` → `bn-v2`）も上げると、ホーム画面のアプリにも確実に反映されます。

## データについて
- 記録はユーザーのスマホ（ブラウザ）の中だけに保存されます。サーバーには送りません。
- 写真解析のときだけ、画像を Cloudflare の AI に送ります（保存はしません）。
- 機種変更に備えて「計算」タブの **データのバックアップ** から書き出し・読み込みができます。
